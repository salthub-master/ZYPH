Thank You for Downloading Drop

If you encounter issues before reaching to a real person try using the solutions below, if you cant find your issue then DM our Support On Discord, Thanks!

Case A : KeySystem says my key is wrong!

1.The servers could be down
2.Make sure you dont have any spaces or extra characters
3.Check if you dont have a firewall blocking Drop

Case B : I get an error saying that the site wasnt found

1.Re-use the bootstrapper if the same issue happens contact support.

Case C : When i press attach nothing happens

1.Make sure you dont have any other exploit on which is interfering with Drop, if this wont fix it then please contact Support.

Case D : When i execute it tells me to attach even tho its already attached!

This issue needs to be reported to Support

Case E : Auto-Attach Crashes Roblox!

Some games have exploit detection like Jailbreak so if you'd like to exploit in Jailbreak then disable autoattach and attach after the game was fully loaded.

Case F : Drop keeps crashing after a few seconds!

1.Try disabling the Auto-Save feauture(in settings) and re-enabling it and report it to us!


Thank You for Using Drop :)